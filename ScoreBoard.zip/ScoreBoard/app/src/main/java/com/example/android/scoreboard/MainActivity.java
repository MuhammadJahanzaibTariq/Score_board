package com.example.android.scoreboard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt,txt2,txt3;
    int sumA=0,sumB=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=findViewById(R.id.team_a_score);
        txt2=findViewById(R.id.team_a_score3);
        txt3=findViewById(R.id.res);
    }
    public void addOneForTeamA(View view) { fun(1); }
    public void addTwoForTeamA(View view) { fun(2); }
    public void addThreeForTeamA(View view) {fun(3); }
    public void addFourForTeamA(View view) { fun(4); }
    public void addFiveForTeamA(View view) { fun(5); }
    public void addSixForTeamA(View view) { fun(6); }
    public void addoneForTeamB(View view) { fun2(1); }
    public void addTwoForTeamB(View view) { fun2(2);}
    public void addthreeForTeamB(View view) { fun2(3); }
    public void addFourForTeamB(View view) { fun2(4); }
    public void addFiveForTeamB(View view) { fun2(5); }
    public void addSixForTeamB(View view) { fun2(6); }
    public void fun(int n)
    {
        sumA+=n;
        txt.setText(String.valueOf(sumA));
    }
    public void fun2(int n)
    {
        sumB+=n;
        txt2.setText(String.valueOf(sumB));
    }

    public void result(View view) {
        if(sumA>sumB)
        {
            txt3.setText("THE WINNER IS Team A !!!");
        }else if(sumA<sumB)
        {
            txt3.setText("THE WINNER IS Team B !!!");
        }else
        {
            txt3.setText("MATCH IS DRAW !!!");
        }
    }
}